# Script Purpose:
# To create a multi-panelled figure consisted of 16 barplots corresponding to the
# IA-Category level for MMR and all its 15 div/states
# for the 1st interval (1996-2007) only
# each barplot is consisted of a gain and loss bar, which should also have their own uniform lines for gains/losses
# but same for that one interval (if comparing against the other figure for the 2nd interval)

# Set Working Directory -------------------
setwd("C:/150918 MMR Barplots/2-Category-1996to2007")

# Load Libraries --------------------------

library(ggplot2)
library(plyr)

# Read Input Data -------------------------

dataCATl <- read.csv(file="Category-1996to2007-Losses.csv", header=TRUE, sep=",")
dataCATg <- read.csv(file="Category-1996to2007-Gains.csv", header=TRUE, sep=",")

# Clean and Subset Data -------------------

# 1. Select columns: include all columns except Category ID 
#*** HERE NOW***
dfL <- subset(dataCATl, select=c(5,7,9,10,11,12))
dfG <- subset(dataCATg, select=c(5,7,9,10,11,12))

# 2. Add Change Type column
type1 <- rep("Loss", nrow(dfL))
type2 <- rep("Gain", nrow(dfG))
dfL <- cbind(dfL, type1)
dfG <- cbind(dfG, type2)


# Change column names for easier reference

# Note the following description of category level column names
# ColA - Domain_name
# ColB - Time_interval
# ColC - Class_name
# ColD - Observed_Annual_Gain/Loss_number_of_elements
# ColE - Gain/Loss_intensity_percent_of_later_year_category
# ColF - Uniform_Intensity_percent_of_interval's_domain
# ColG - Change Type i.e. loss/gain 

list <- c("ColA","ColB","ColC","ColD","ColE","ColF","ColG")
colnames(dfL) <- c(list)
colnames(dfG) <- c(list)

# 6. Combine separate Loss and Gain datasets into one dataframe
dfCAT <- rbind(dfL, dfG)

# Generate Plots ------------------------

# Plot 1: Gain and Loss Intensities only
plotCAT <- ggplot() + geom_bar(data=dfCAT, aes(x=ColC, y=ColE, fill=ColG), stat="identity", position=position_dodge())
plotCAT <- plotCAT  + geom_hline(data=dfCAT, aes(yintercept=ColF, colour="#000000"), linetype="dashed") # Uniform line
plotCAT <- plotCAT  + facet_wrap(~ColA)
plotCAT <- plotCAT  + labs(x="Category", y="Gain/Loss Intensity")
# plotCAT <- plotCAT  + scale_x_discrete(labels=c("BUA","FOR","IAS","MNG","OPM","RPD","RBR","SHB","WTR","BRG"))
plotCAT <- plotCAT  + scale_fill_manual(values=c("#b43507","#8acd66"), labels=c("Loss Intensity","Gain Intensity"))
plotCAT <- plotCAT  + scale_colour_manual(values=c("#000000"), labels=c("Uniform Intensity"))
plotCAT <- plotCAT  + theme(panel.grid.minor=element_blank())
plotCAT <- plotCAT  + theme(legend.title=element_blank(), legend.position=c(0.9,0.9), legend.box="vertical")

# Plot 2: Loss Intensity only
plotL <- ggplot() + geom_bar(data=dfL, aes(x=ColC, y=ColE, fill=ColG), stat="identity")
plotL <- plotL + geom_hline(data=dfL, aes(yintercept=ColF, colour="#000000"), linetype="dashed") # Uniform line
plotL <- plotL  + facet_wrap(~ColA)
plotL <- plotL + labs(x="Category", y="Loss Intensity (% of Category)")
# plotL <- plotL + scale_x_discrete(labels=c("BUA","FOR","IAS","MNG","OPM","RPD","RBR","SHB","WTR","BRG"))
plotL <- plotL + scale_fill_manual(values=c("#b43507"), name="", labels=c("Loss Intensity"))
plotL <- plotL + scale_colour_manual(values=c("#000000"), name="", labels=c("Uniform Intensity"))
plotL <- plotL + theme(panel.grid.minor=element_blank(), legend.position=c(0.9,0.9), legend.box="vertical")

# Plot 3: Gain Intensity only
plotG <- ggplot() + geom_bar(data=dfG, aes(x=ColC, y=ColE, fill=ColG), stat="identity")
plotG <- plotG + geom_hline(data=dfG, aes(yintercept=ColF, colour="#000000"), linetype="dashed") # Uniform line
plotG <- plotG  + facet_wrap(~ColA)
plotG <- plotG + labs(x="Category", y="Category Intensity (% of Category)")
# plotG <- plotG + scale_x_discrete(labels=c("BUA","FOR","IAS","MNG","OPM","RPD","RBR","SHB","WTR","BRG"))
plotG <- plotG + scale_fill_manual(values=c("#8acd66"), name="", labels=c("Gain Intensity"))
plotG <- plotG + scale_colour_manual(values=c("#000000"), name="", labels=c("Uniform Intensity"))
plotG <- plotG + theme(panel.grid.minor=element_blank(), legend.position=c(0.9,0.9), legend.box="vertical")

# Plot 4: Pixel counts for both gains and losses in this interval
plotPIX <- ggplot() + geom_bar(data=dfCAT, aes(x=ColC, y=ColD, fill=ColG), stat="identity", position=position_dodge())
#plotCAT <- plotCAT  + geom_hline(data=dfCAT, aes(yintercept=ColF, colour="#000000"), linetype="dashed") # Uniform line
plotPIX <- plotPIX  + facet_wrap(~ColA)
plotPIX <- plotPIX  + labs(x="Category", y="Pixel Sum")
# plotCAT <- plotCAT  + scale_x_discrete(labels=c("BUA","FOR","IAS","MNG","OPM","RPD","RBR","SHB","WTR","BRG"))
plotPIX <- plotPIX  + scale_fill_manual(values=c("#b43507","#8acd66"), labels=c("Loss Intensity","Gain Intensity"))
#plotCAT <- plotCAT  + scale_colour_manual(values=c("#000000"), labels=c("Uniform Intensity"))
plotPIX <- plotPIX  + theme(panel.grid.minor=element_blank())
plotPIX <- plotPIX  + theme(legend.title=element_blank(), legend.position=c(0.9,0.9), legend.box="vertical")

# Save Outputs --------------------------

# Output boxplots to a PDF file
ggsave(plotCAT, file="IA-Category-Gain & Loss Intensities-All Domains-1996to2007.pdf", width=29.89, height=25, units="cm", dpi=300)
ggsave(plotL,   file="IA-Category-Only Loss Intensities-All Domains-1996to2007.pdf", width=29.89, height=25, units="cm", dpi=300)
ggsave(plotG,   file="IA-Category-Only Gain Intensities-All Domains-1996to2007.pdf", width=29.89, height=25, units="cm", dpi=300)
ggsave(plotPIX,   file="IA-Category-Gain & Loss-Pixel Sum-All Domains-1996to2007.pdf", width=29.89, height=25, units="cm", dpi=300)

# Export dataframe to CSV file
write.csv(dfCAT, file="IA-Category-All Domains-1996to2007-Rscript-outputR.csv")
